﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace business
{
    class Program
    {

        static int count = 0, countforcitytogo = 0, row = 0, column = 0,countforhotel=0;
        
        static string [] hotelname = new string[100];
        static int[] hotelprice = new int[100];
      
        static void Main(string[] args)
        {
            loadfileforhotel();
            adminfunctionality();

            Console.ReadKey();
        }

        //admin functionalities

        static void adminfunctionality()
        {
            // topheader2();

            string reslut;
            //topheader();
            Console.SetCursorPosition(8, 10);
            Console.WriteLine("1 . Add new airline:");
            Console.SetCursorPosition(48, 10);
            Console.WriteLine("2. delete airline:");
            Console.SetCursorPosition(8, 12);
            Console.WriteLine("3. hotels :");
            Console.SetCursorPosition(48, 12);
            Console.WriteLine("4. Update price");
            Console.SetCursorPosition(8, 14);
            Console.WriteLine("5. REcord of pessangers :");
            Console.SetCursorPosition(48, 14);
            Console.WriteLine("6. offers:");
            Console.SetCursorPosition(8, 16);
            Console.WriteLine("7. Emoplpoy data:");
            Console.SetCursorPosition(48, 16);
            Console.WriteLine("8. Flight details / change flight time :");
            Console.SetCursorPosition(8, 18);
            Console.WriteLine("9. Account:");
            Console.SetCursorPosition(48, 18);
            Console.WriteLine("10. city change:");
            Console.SetCursorPosition(8, 20);
            Console.WriteLine("enter your choice:");
            Console.SetCursorPosition(30, 20);
            reslut = Console.ReadLine();
            if (int.
                TryParse(reslut, out int num))
            {
                if (num >= 1 && num <= 9)
                {
                    checkcondition1(num);
                }
                else
                {
                    Console.Write("invalid input");
                }

            }
            else
            {
                Console.Write("invalid input");

            }



            System.Threading.Thread.Sleep(500);
        }



        static void checkcondition1(int i)
        {
            if (i >= 1 && i <= 10)
            {
                while (i != -1)
                {

                    if (i == 4)
                    {
                        //updatepriceis();
                    }
                    else if (i == 1)
                    {
                       // addnewairline();
                    }
                    else if (i == 2)
                    {
                        //deleteairline();
                    }
                    else if (i == 3)
                    {
                        hotel();
                    }
                    else if (i == 5)

                    {
                        //recordofpessenger();
                    }
                    else if (i == 8)
                    {
                        //flightchanges();
                    }
                    else if (i == 6)
                    {
                        // offersforusers();
                    }
                    else if (i == 9)
                    {
                        // accountadmin();
                    }
                    else if (i == 10)
                    {
                        //citychange();
                    }
                    else
                    {
                        //empolye();
                    }
                    adminfunctionality();
                }
            }
            else
            {
                Console.Write("invalid input");
                adminfunctionality();
            }
        }
        //// functionality no1 add new airline
        //static void addnewairline()
        //{

        //    string condition;
        //    // topheader2();
        //    airlineveiw();
        //    Console.SetCursorPosition(4, count + 8);
        //    Console.WriteLine("did you want to add new line yes or no:");
        //    condition = Console.ReadLine();
        //    if (condition == "yes")
        //    {

        //        Console.SetCursorPosition(4, count + 10);
        //        Console.WriteLine("enter new airline:");
        //        condition = Console.ReadLine();
        //        airlinename[count] = condition;
        //        count = count + 1;

        //        newcity();



        //    }
        //}
        ////supporting functions
        //static void airlineveiw()
        //{
        //    Console.SetCursorPosition(6, 8);
        //    for (int i = 0; i < count; i++)
        //    {
        //        Console.WriteLine(airlinename[i]);
        //        Console.WriteLine();
        //        Console.WriteLine("      ");
        //    }
        //}
        //static void loadfileforairline()
        //{

        //    string path = "C:\\Users\\hp\\Documents\\1st semester\\project\\airline.txt";
        //    if (File.Exists(path))
        //    {
        //        StreamReader fileVariable = new StreamReader(path);
        //        string record;
        //        while ((record = fileVariable.ReadLine()) != null)
        //        {
        //            airlinename[count] = record;
        //            count++;
        //        }
        //        fileVariable.Close();
        //    }
        //    else
        //    {
        //        Console.Write("file does not exist");
        //    }

        //}

        //static void newcity()
        //{

        //    string departure, arrival;
        //    for (int i = 0; i < countforcitytogo; i++)
        //    {
        //        Console.WriteLine("departure city name: ");
        //        departure = Console.ReadLine();
        //        Console.WriteLine("Arrival city name: ");
        //        arrival = Console.ReadLine();
        //        citytogo[row + 1, i] = Console.ReadLine();
        //        Console.WriteLine();
        //        Console.Write("        ");
        //        Console.Write(" Prices  :");
        //        priceofairline[row + 1, i] = int.Parse(Console.ReadLine());
        //        Console.WriteLine();
        //        Console.Write("        ");
        //        Console.Write("time:  ");
        //        flighttime[row + 1, i] = int.Parse(Console.ReadLine());
        //        Console.WriteLine();
        //    }
        //}
       static void hotel()
        {
            Console.Clear();
            // topheader2();
            string input;
            int check;

            // topheader1();
            Console.SetCursorPosition(4, 8);
            Console.Write("1 .if you want to view all hotels ");
            Console.SetCursorPosition(4, 10);
            Console.Write("2. if you want to add hotels :");
            Console.SetCursorPosition(4, 12);
            Console.Write("3. if you ant to remove hotel:");
            Console.SetCursorPosition(4, 14);
            Console.Write("4. if you want to update price of hotel:");
            Console.SetCursorPosition(4, 16);
            Console.Write("enter your choice:");
            input = Console.ReadLine();
            if (int.
                 TryParse(input, out  check))
            {
                if (check == 1)
                {
                    viewhotel();
                }

                else if (check == 2)
                {
                    addhotel();
                   
                }

                else if (check == 3)
                {
                    deletehotel();
                   
                }

                else
                {
                    updatepriceofhotel();
                    
                }
            }
        }

        static void loadfileforhotel()
        {
            string path = "C:\\Users\\hp\\Documents\\2nd semester\\opp and pd\\week1\\business\\hotel.txt";
            if (File.Exists(path))
            {
                StreamReader fileVariable = new StreamReader(path);

                string  name;

                while (!(fileVariable.EndOfStream))
                {
                    name = fileVariable.ReadLine();
                    if (name != " ")
                    {
                        string[] splitarray = name.Split(',');

                        hotelname[countforhotel] = splitarray[0];
                        hotelprice[0] =int.Parse( splitarray[1]);
                        countforhotel++;
                    }
                }
                fileVariable.Close();
            }
        }
        static void storefile()
        {

            string path = "C:\\Users\\hp\\Documents\\2nd semester\\opp and pd\\week1\\business\\hotel.txt";
            StreamWriter fileVariable = new StreamWriter(path);
            for(int x=0;x<countforhotel;x++)
            {
                fileVariable.Write(hotelname[x]);
                fileVariable.Write(",");
                fileVariable.Write(hotelprice[x]);
                fileVariable.WriteLine();
            }
            fileVariable.Close();
        }
        //functionalities
       static void viewhotel()
        {
           Console.Clear();
            Console.SetCursorPosition(4, 20);
            Console.Write( "hotel name              hotel price");
            for (int i = 0; i < countforhotel; i++)
            {
                Console.Write(hotelname[i]);
                  Console.Write("         ");
                Console.Write ( hotelprice[i]);
                Console.WriteLine();
               
            }
        }

       static void addhotel()
        {
            viewhotel();
            countforhotel = countforhotel + 1;
            Console.SetCursorPosition(4, countforhotel+2);
            Console.Write("add hotel:");
            hotelname[countforhotel] = Console.ReadLine() ;
            Console.SetCursorPosition(4, countforhotel+4);
            Console.Write("enter hotel price:");
           hotelprice[count]=int.Parse(Console.ReadLine());
            Console.SetCursorPosition(4, countforhotel+6);
            Console.Write("hotel is added sucessfully");
            
            storefile();
        }
       static void deletehotel()
        {
            int i = 0;
            bool check;
            string hotelnameis;
            viewhotel();
            Console.SetCursorPosition(4, countforhotel+2);
            Console.Write("which hotel you want to delete:");
            hotelnameis = Console.ReadLine(); ;
            check = hotelcheck(hotelnameis);
            if (check == true)
            {
                while (i < count)
                {
                    if (hotelnameis == hotelname[i])
                    {
                        for (int j = i; j < countforhotel - 1; j++)
                        {
                            hotelname[j] = hotelname[j + 1];

                            hotelprice[j] = hotelprice[j + 1];
                        }
                    }
                    else
                    {
                        i++;
                    }

                    countforhotel--;
                }
            }
            else
            {
                Console.SetCursorPosition(4,countforhotel+2);
                Console.Write( "invalid input");
                deletehotel();
            }
            storefile();
        }
       static void updatepriceofhotel()
        {
            bool check;
            int count = 0;
            viewhotel();
            Console.SetCursorPosition(4, countforhotel+2);
            string hotelnameis;
            Console.Write("which hotel's price you want to update:");
             hotelnameis=Console.ReadLine();
            check = hotelcheck(hotelnameis);
            if (check == true)
            {
                for (int c = 0; c < countforhotel; c++)
                {
                    if (hotelnameis != hotelname[c])
                    {
                        count = count + 1;
                    }
                    if (hotelnameis == hotelname[c])
                    {
                        break;
                    }
                }
                Console.SetCursorPosition(4, countforhotel +4);
                Console.Write("enter price:");
                 hotelprice[count]=int.Parse(Console.ReadLine());
            }
            else
            {
                Console.SetCursorPosition(4, countforhotel+4);
                Console.Write("invalid hotel name");
                updatepriceofhotel();
            }
            storefile();
        }
       static bool hotelcheck(string hotelnamie)
        {
            bool flag = false;
            for (int i = 0; i < countforhotel; i++)
            {
                if (hotelnamie == hotelname[i])
                {
                    flag = true;
                    break;
                }
            }
            return flag;
        }

    }
}

