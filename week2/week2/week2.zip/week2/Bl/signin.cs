﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week2.Bl
{
    class Signin
    {
        public string name;
        public string password;
    }
}
