﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week2.Bl
{
    class Class1
    {
        public string name;
        public int rollnumber;
        public float cgpa;
        public char hostel;
        public string department;
    }
    
}
