﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business.BL
{
    class Admin
    {
        public int count = 0;
        public int  countforhotel=0;
        public int  row=0;
        public int column = 0;
        public string hotelname;
        public int hotelprice;
        public string name;
        public string password;

    }
}
